import datetime
import smtplib
from time import sleep
import time
import pyttsx3
import speech_recognition as sr
# import wikipedia
import webbrowser
from googlesearch import search

engine = pyttsx3.init('sapi5')
voices = engine.getProperty("voices")  # getting details of current voice
# print(voices[0].id)
engine.setProperty('voice', voices[0].id)


def ask_to_user():
    print("\n---> open youtube\n---> open today news\n---> open my achivement\n---> play music\n---> live time\n---> open instagram\n\n")
    print("Say **Exit Program** for Break the code\n\n ")
    time.sleep(10)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()

def wishMe():
    hour = int(datetime.datetime.now().hour)
    if hour >= 0 and hour < 12:
        speak("Good Morning!")

    elif hour >= 12 and hour < 18:
        speak("Good Afternoon!")

    else:
        speak("Good Evening!")

    speak("I am Jarvis Sir. Please tell me how may I help you")


def takeCommand():
    # It make microphone input from the user and return staring output

    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source)

    try:
        print("Recognizing...")
        query = r.recognize_google(audio, language='en-IN')
        print(f"User said : {query}\n")
        speak(f"User said : {query}\n")

    except Exception as e:
        # print(e)
        print("Say that again please...")
        speak("Say that again please...")
        return "None"
    return query


def sendEmail(to, content):
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()
    server.starttls()
    server.login('sejalvishnoi32@gmail.com', 'jwed eftw ssoy rxkb')
    server.sendmail('sejalvishnoi32@gmail.com', to, content)
    server.close()


if __name__ == "__main__":

    wishMe()
    ask_to_user()
    # sleep(3) 
    while True:
    # if 1:
        query = takeCommand().lower()

        # logic for executing task based on query
        # if 'wikipedia' in query:
        #     speak("Searching Wikipedia....")
        #     query = query.replace("wikipedia", "")
        #     results = wikipedia.summary(query, sentences=2)
        #     speak("According to wikipedia")
        #     print(results)
        #     speak(results)
            
        if 'open youtube' in query:
            webbrowser.open("youtube.com")

        elif 'open gmail' in query:
            webbrowser.open("https://mail.google.com/mail/u/0/")

        elif 'open news' in query:
            webbrowser.open("https://www.aajtak.in/")

        elif 'play music' in query:
            webbrowser.open("https://www.youtube.com/watch?v=rtOvBOTyX00&ab_channel=ChristinaPerri")

        elif 'open status' in query:
            webbrowser.open("https://drive.google.com/file/d/1EmDWBD373esDYRvl1HPmU5u87407ehAy/view")

        elif 'current time' in query:
            strTime = datetime.datetime.now().strftime("%H:%M:%S")
            print(strTime)
            speak(f"Sir , the time is {strTime}")

        elif 'open instagram' in query:
            webbrowser.open("https://www.instagram.com/")
        
        elif 'exit program' in query:
            break

        elif 'send email' in query:
            try:
                print("what do you want to write in the email ?\nListning...")
                speak("what do you want to write in the email ?")
                content = takeCommand()
                to = "sejalvishnoi32@gmail.com"
                sendEmail(to, content)
                speak("🙌 Email has been sent! 🙌")
            except Exception as e:
                print(e)
                speak("Sorry my friend Sejal , i am not able to send this email")