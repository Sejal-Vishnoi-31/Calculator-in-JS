import datetime
def gettime():
    return datetime.datetime.now()
                               

def take(k):
    if k == 1:
        c = int(input("enter 1 for excersice and 2 for food  \n "))
        if (c == 1):
            value = input("type here \n")
            with open("jay_exe.txt", "a") as op:
                op.write(str([str(gettime())])+": "+value+"\n")
            print("Successfully written ")
        elif (c == 2):
            value = input("type here \n")
            with open("jay_food.txt", "a") as op:
                op.write(str([str(gettime())])+": "+value+"\n")
            print("Successfully written ")
    if (k == 2):
        c = int(input("enter 1 for excersice and 2 for food\n"))
        if (c == 1):
            value = input("type here \n")
            with open("Sejal_exe.txt", "a") as op:
                op.write(str([str(gettime())])+": "+value+"\n")
            print("Successfully written ")
        elif (c == 2):
            value = input("type here \n")
            with open("Sejal_food.txt", "a") as op:
                op.write(str([str(gettime())])+": "+value+"\n")
            print("Successfully written ")
    else:
        print("please input invlid input only for jay and sejal \n ")


def retrieve(k):
    if k == 1:
        c = int(input("enter 1 for excersice and 2 for food \n "))
        if (c == 1):
            with open("jay_exe.txt") as op:
                for i in op:
                    print(i, end="")
        elif (c == 2):

            with open("jay_food.txt") as op:
                for i in op:
                    print(i, end="")
    elif (k == 2):
        c = int(input("enter 1 for excersice and 2 for food \n "))
        if (c == 1):
            with open("Sejal_exe.txt") as op:
                for i in op:
                    print(i, end="")

        elif (c == 2):

            with open("Sejal_food.txt") as op:
                for i in op:
                    print(i, end="")
    else:
        print("please input invlid input only for jay and sejal  \n ")


print("Health Manegement system : \n")
a = int(input("enter 1 for lock the value  and 2 for retrieve \n "))

if a == 1:
    b = int(input("please 1 for jay and 2 for sejal \n "))
    take(b)
else:
    b = int(input("please 1 for jay and 2 for sejal \n "))
    retrieve(b)