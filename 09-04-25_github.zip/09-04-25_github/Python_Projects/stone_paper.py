#stone , pepar , seissors
import random
lst=["s" , "p" ,"Si"] 

chance = 5
no_of_chance = 0
jay_point = 0
sejal_point = 0

print("\n \n \t \t STONE,PEPAR,SEISSORS \n \n ")
print("s for stone \np for pepar \nS for seissors")

for i in range(chance):

    sejal_input = input("STONE,PEPAR,SEISSORS :::::\n")
    jay_input = random.choice(lst)
    if sejal_input==jay_input:
        print("Tie both 0 point to each \n")

    elif sejal_input=="s" and jay_input=="p":
        jay_point=jay_point+1
        print(f"your guess is {sejal_input} and jay guess is {jay_point} \n ")
        print("jay wins 1 point\n")
        print(f"jay point is {jay_point} and sejal point is {sejal_point}")

    elif sejal_input=="s" and jay_input=="Si":
        sejal_point=sejal_point+1
        print(f"your guess is {sejal_input} and jay guess is {jay_point} \n ")
        print("sejal wins 1 point\n")
        print(f"jay point is {jay_point} and sejal point is  {sejal_point}")
     
    elif sejal_input=="p" and jay_input=="s":
        sejal_point=sejal_point+1
        print(f"your guess is {sejal_input} and jay guess is {jay_point} \n ")
        print("sejal wins 1 point\n")
        print(f"jay point is {jay_point} and sejal point is  {sejal_point}")

    elif sejal_input=="p" and jay_input=="Si":
        jay_point=jay_point+1
        print(f"your guess is {sejal_input} and jay guess is {jay_point} \n ")
        print("jay wins 1 point\n")
        print(f"jay point is {jay_point} and sejal point is  {sejal_point}")
    
    elif sejal_input=="Si" and jay_input=="s":
        jay_point=jay_point+1
        print(f"your guess is {sejal_input} and jay guess is {jay_point} \n ")
        print("jay wins 1 point\n")
        print(f"jay point is {jay_point} and sejal point is  {sejal_point}")

    elif sejal_input=="Si" and jay_input=="p":
        sejal_point=sejal_point+1
        print(f"your guess is {sejal_input} and jay guess is {jay_point} \n ")
        print("sejal wins 1 point\n")
        print(f"jay point is {jay_point} and sejal point is  {sejal_point}")
  
    else:

        print("you have input wrong \n\n")

    no_of_chance=no_of_chance +1
    print(f"{chance-no_of_chance} is left out of {chance} \n \n")


print("\n\nGame over\n\n")

if jay_point > sejal_point:
    print("Jay Wins and you looser")
elif jay_point < sejal_point:
    print("sejal wins and jay looser")
else:
    print("tie")


print(f"sejal point is {sejal_point} and jay point is {jay_point} ")
  