# create a library class
# displet book
# lend book
# add book 
# retrun book

# Sejallibrary = Library(listofbook,library_name)

# dictionary (books-nameofperson)

# create a main function and run and infinite while loop asking user for their input

# class Library:
#     def __init__(self, list, name):
#         self.booklist = list
#         self.name = name
#         self.lendDict = {}

#     def displayBook(self):
#         print(f"We have following books in our library: {self.name}")
#         for book in self.booklist:
#             print(book)

#     def lendBook(self, user, book):
#         if book not in self.lendDict.keys():
#             self.lendDict.update({book:user})
#             print("Lender-book database has been updated. You can take the book now")
#         else:
#             print(f"Book is already being user by {self.lendDict[book]}")    
    
#     def addBoook(self, book):
#         self.booklist.append(book)
#         print("Book has been added to the book list")

#     def returnBook(self, book):
#         self.booklist.remove(book)

# if __name__ == '__main__':
#     sejal = Library(['python','C++ Basics','harry potter','DSA','English'],"Deploperlibrary")
#     while(True):
#         print(f"Welcome to the {sejal.name} library. Enter Your choice to continue")
#         print("1. display Books")
#         print("2. lend Books")
#         print("3. Add Books")
#         print("4. Return Books")
#         user_choice = int(input())

#         if user_choice == 1:
#             sejal.displayBook()

#         elif user_choice == 2:
#             book = input("Enter the name of the book you want to lend:")
#             user = input("Enter your name:")
#             sejal.lendBook(user,book)

#         elif user_choice == 3:
#             book = input("Enter the name of the book you want to add:")
#             sejal.addBoook(book)

#         elif user_choice == 4:
#             book = input("Enter the name of the book you want to return:")
#             sejal.returnBook(book)

#         else:
#             print("Not a vaild option")

#         print("Press q to quit and c to continue:")
#         user_choice2 = ""
#         while(user_choice2!="c" and user_choice2!="q"):
#             user_choice2 = input()
#             if user_choice2 == "q":
#                 exit()

#             elif user_choice2 == "c":
#                continue   

#-----------------------------------jay code---------------------------------------

class Library:
    def __init__(self, list, name):
        self.booklist = list
        self.name = name
        self.lendDict = {}  

    def displayBook(self):
        print(f"We have following books in our library: {self.name}")
        for book in self.booklist:
            print(book)

    def lendBook(self, user, book):
        if book not in self.lendDict.keys():
            self.lendDict.update({book:user})
            print("Lender-book database has been updated. You can take the book now")
        else:
            print(f"Book is already being user by {self.lendDict[book]}")    
    
    def addBoook(self, book):
        self.booklist.append(book)
        print("Book has been added to the book list")

    def returnBook(self, book):
        self.booklist.remove(book)

if __name__ == '__main__':
    sejal = Library(['python','C++ Basics','harry potter','DSA','English'],"Deploperlibrary")
    while(True):
        print(f"Welcome to the {sejal.name} library. Enter Your choice to continue")
        print("1. display Books")
        print("2. lend Books")
        print("3. Add Books")
        print("4. Return Books")
        user_choice = int(input())

        if user_choice == 1:
            sejal.displayBook()

        elif user_choice == 2:
            book = input("Enter the name of the book you want to lend:")
            user = input("Enter your name:")
            sejal.lendBook(user,book)

        elif user_choice == 3:
            book = input("Enter the name of the book you want to add:")
            sejal.addBoook(book)

        elif user_choice == 4:
            book = input("Enter the name of the book you want to return:")
            sejal.returnBook(book)

        else:
            print("Not a vaild option")

        print("Press q to quit and c to continue:")
        user_choice2 = ""
        while(user_choice2!="c" and user_choice2!="q"):
            user_choice2 = input()
            if user_choice2 == "q":
                exit()

            elif user_choice2 == "c":
               continue   
        
 


